#pragma once
 class Cuadrado
{
private:
		int lado;
		int area;
public:
	Cuadrado(void); //Construtor
	int Get_lado();				// No devuelve nada solo asigna el atributo
	int Get_area();
	void Set_lado(int L);    
	void Set_area(int a);
	int Calcular();
};

