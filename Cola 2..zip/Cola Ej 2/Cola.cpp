#include "pch.h"
#include "Cola.h"
Cola::Cola (void) {
	frente = -1;
	final = 0;
}
void Cola::encolar(int x) {
	C[++frente] = x;
}
int Cola::desencolar() {
	int a = C[final++];
	return a;
}
bool Cola::lleno() {
	if (frente == M - 1)
		return true;
}
bool Cola::vacio() {
	if (final > frente)
		return true;
}