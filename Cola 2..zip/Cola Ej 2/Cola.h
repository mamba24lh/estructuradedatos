#pragma once
#define M 25
class Cola
{
private:
	int frente;
	int final;
	int C[M];
public:
	Cola(void);
	void encolar(int x);
	int desencolar();
	bool lleno();
	bool vacio();

};

