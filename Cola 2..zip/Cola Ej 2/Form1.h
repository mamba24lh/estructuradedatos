#pragma once
#include "Cola.h"

namespace CppCLRWinformsProjekt {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Zusammenfassung f�r Form1
	/// </summary>
	int pos = 0;
	int posinv = 0;
	Cola C1;
	Cola C2;
	Cola C3;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Konstruktorcode hier hinzuf�gen.
			//
		}

	protected:
		/// <summary>
		/// Verwendete Ressourcen bereinigen.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^ txtDato;
	private: System::Windows::Forms::Button^ btnEncolar;
	private: System::Windows::Forms::DataGridView^ Grid;
	protected:


	private: System::Windows::Forms::DataGridViewTextBoxColumn^ Column1;
	private: System::Windows::Forms::Button^ btnDes;
	private: System::Windows::Forms::Button^ txtInv;
	private: System::Windows::Forms::DataGridView^ GridInv;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ Column2;


	protected:

	private:
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung.
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtDato = (gcnew System::Windows::Forms::TextBox());
			this->btnEncolar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnDes = (gcnew System::Windows::Forms::Button());
			this->txtInv = (gcnew System::Windows::Forms::Button());
			this->GridInv = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Grid))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->GridInv))->BeginInit();
			this->SuspendLayout();
			// 
			// txtDato
			// 
			this->txtDato->Location = System::Drawing::Point(26, 26);
			this->txtDato->Name = L"txtDato";
			this->txtDato->Size = System::Drawing::Size(100, 20);
			this->txtDato->TabIndex = 0;
			// 
			// btnEncolar
			// 
			this->btnEncolar->Location = System::Drawing::Point(165, 26);
			this->btnEncolar->Name = L"btnEncolar";
			this->btnEncolar->Size = System::Drawing::Size(75, 23);
			this->btnEncolar->TabIndex = 1;
			this->btnEncolar->Text = L"Encolar";
			this->btnEncolar->UseVisualStyleBackColor = true;
			this->btnEncolar->Click += gcnew System::EventHandler(this, &Form1::btnEncolar_Click);
			// 
			// Grid
			// 
			this->Grid->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) { this->Column1 });
			this->Grid->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->Location = System::Drawing::Point(12, 73);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(147, 150);
			this->Grid->TabIndex = 2;
			this->Grid->RowCount = 25;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Cola";
			this->Column1->Name = L"Column1";
			// 
			// btnDes
			// 
			this->btnDes->Location = System::Drawing::Point(165, 90);
			this->btnDes->Name = L"btnDes";
			this->btnDes->Size = System::Drawing::Size(75, 23);
			this->btnDes->TabIndex = 3;
			this->btnDes->Text = L"Desencolar";
			this->btnDes->UseVisualStyleBackColor = true;
			this->btnDes->Click += gcnew System::EventHandler(this, &Form1::btnDes_Click);
			// 
			// txtInv
			// 
			this->txtInv->Location = System::Drawing::Point(165, 142);
			this->txtInv->Name = L"txtInv";
			this->txtInv->Size = System::Drawing::Size(75, 23);
			this->txtInv->TabIndex = 4;
			this->txtInv->Text = L"Invertir";
			this->txtInv->UseVisualStyleBackColor = true;
			this->txtInv->Click += gcnew System::EventHandler(this, &Form1::txtInv_Click);
			// 
			// GridInv
			// 
			this->GridInv->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->GridInv->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->GridInv->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) { this->Column2 });
			this->GridInv->Location = System::Drawing::Point(276, 73);
			this->GridInv->Name = L"GridInv";
			this->GridInv->Size = System::Drawing::Size(143, 150);
			this->GridInv->TabIndex = 5;
			this->GridInv->RowCount = 25;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Invertida";
			this->Column2->Name = L"Column2";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(473, 261);
			this->Controls->Add(this->GridInv);
			this->Controls->Add(this->txtInv);
			this->Controls->Add(this->btnDes);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnEncolar);
			this->Controls->Add(this->txtDato);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Grid))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->GridInv))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
private: System::Void btnEncolar_Click(System::Object^ sender, System::EventArgs^ e) {
	if (C1.lleno() == true)
		MessageBox::Show("La cola esta llena");
	else
	{
		int x = Convert::ToInt32(txtDato->Text);
		C1.encolar(x);
		Grid->Rows[pos++]->Cells[0]->Value = x;
	}
}
private: System::Void btnDes_Click(System::Object^ sender, System::EventArgs^ e) {
	if (C1.vacio() == true)
		MessageBox::Show("La cola esta vacia");
	else
	{
		C1.desencolar();
		Grid->Rows->RemoveAt(0);
	}
}
private: System::Void txtInv_Click(System::Object^ sender, System::EventArgs^ e) {
	do {
		while (pos > 0)
		{
			int a = C1.desencolar();
			C2.encolar(a);
			pos--;
		}
		int aux2 = C1.desencolar();
		C3.encolar(aux2);
		GridInv->Rows[posinv]->Cells[0]->Value = aux2;
		while (C2.vacio() == false)
		{
			int aux3 = C2.desencolar();
			C1.encolar(aux3);
			pos++;
		}
	} while (C1.vacio()==true||C2.vacio()==true);


	
}
};
}
