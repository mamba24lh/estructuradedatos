#include "StdAfx.h"
#include "Cola.h"


Cola::Cola(void)
{
	cola[N]=0;
	frente=-1;
	final=-1;

}
int Cola::Get_frente()
{
	return frente;
}
int Cola::Get_final()
{
	return final;
}
void Cola::encolar(int x)
{
	final++;
	cola[final]=x;
}
int Cola::desencolar()
{
	frente++;
	return cola[frente];
}
bool Cola::Cola_vacia()
{
	if(frente==final) 
	{ 
		return true;
	}
	else 
	{
		return false;
	}
}
bool Cola::Cola_llena()
{
		if(final==N-1) 
	{ 
		return true;
	}
	else 
	{
		return false;
	}
}
