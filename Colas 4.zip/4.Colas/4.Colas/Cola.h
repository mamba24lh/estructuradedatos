#pragma once
#define N 30
class Cola
{
private:
	int frente;
	int final;
	int cola[N];
public:
	Cola(void);
	int Get_frente();
	int Get_final();
	void encolar(int x);
	int desencolar();
	bool Cola_llena();
	bool Cola_vacia();
};

