#include "StdAfx.h"
#include "COMPLEJO.h"

CCOMPLEJO::CCOMPLEJO(void)
{

}

	void CCOMPLEJO:: Set_real(double r)
	{
	real = r;
	}
	void CCOMPLEJO::Set_imag(double i)
	{
	imag= i;
	}
	double CCOMPLEJO::Get_real()
	{
		return real;
	}
	double CCOMPLEJO::Get_imag()
	{
		return imag;
	}
	void CCOMPLEJO::suma(CCOMPLEJO a, CCOMPLEJO b)
	{
		real = a.real + b.real;
		imag = a.imag + b.imag;
	}