#pragma once
 class CCOMPLEJO
{
private:
	double real;
	double imag;
public:
	CCOMPLEJO(void);
	CCOMPLEJO(double r,double i);
	void Set_real(double r);
	void Set_imag(double i);
	double Get_real();
	double Get_imag();
	void suma (CCOMPLEJO a, CCOMPLEJO b); // No es necesaria a�adir el const ni el &
};

