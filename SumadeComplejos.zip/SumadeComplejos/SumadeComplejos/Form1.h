#pragma once
#include "COMPLEJO.h"
#include <iostream>
#include <msclr\marshal_cppstd.h>

namespace SumadeComplejos {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;  //a�adila wacho
	using namespace msclr::interop; //a�adila wacho

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtreal1;
	protected: 
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtimag1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtreal2;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtimag2;
	private: System::Windows::Forms::Label^  l�;
	private: System::Windows::Forms::TextBox^  txtrealsuma;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtimagsuma;
	private: System::Windows::Forms::Button^  btbsuma;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label9;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtreal1 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtimag1 = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtreal2 = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtimag2 = (gcnew System::Windows::Forms::TextBox());
			this->l� = (gcnew System::Windows::Forms::Label());
			this->txtrealsuma = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtimagsuma = (gcnew System::Windows::Forms::TextBox());
			this->btbsuma = (gcnew System::Windows::Forms::Button());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// txtreal1
			// 
			this->txtreal1->Location = System::Drawing::Point(159, 41);
			this->txtreal1->Name = L"txtreal1";
			this->txtreal1->Size = System::Drawing::Size(100, 20);
			this->txtreal1->TabIndex = 0;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(40, 44);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(30, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"  real";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(40, 91);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(57, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"imaginario ";
			// 
			// txtimag1
			// 
			this->txtimag1->Location = System::Drawing::Point(159, 88);
			this->txtimag1->Name = L"txtimag1";
			this->txtimag1->Size = System::Drawing::Size(100, 20);
			this->txtimag1->TabIndex = 2;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(40, 152);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(24, 13);
			this->label3->TabIndex = 5;
			this->label3->Text = L"real";
			// 
			// txtreal2
			// 
			this->txtreal2->Location = System::Drawing::Point(159, 149);
			this->txtreal2->Name = L"txtreal2";
			this->txtreal2->Size = System::Drawing::Size(100, 20);
			this->txtreal2->TabIndex = 4;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(40, 194);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(54, 13);
			this->label4->TabIndex = 7;
			this->label4->Text = L"imaginaria";
			// 
			// txtimag2
			// 
			this->txtimag2->Location = System::Drawing::Point(159, 191);
			this->txtimag2->Name = L"txtimag2";
			this->txtimag2->Size = System::Drawing::Size(100, 20);
			this->txtimag2->TabIndex = 6;
			// 
			// l�
			// 
			this->l�->AutoSize = true;
			this->l�->Location = System::Drawing::Point(40, 258);
			this->l�->Name = L"l�";
			this->l�->Size = System::Drawing::Size(24, 13);
			this->l�->TabIndex = 9;
			this->l�->Text = L"real";
			// 
			// txtrealsuma
			// 
			this->txtrealsuma->Location = System::Drawing::Point(159, 255);
			this->txtrealsuma->Name = L"txtrealsuma";
			this->txtrealsuma->Size = System::Drawing::Size(100, 20);
			this->txtrealsuma->TabIndex = 8;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(40, 290);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(55, 13);
			this->label6->TabIndex = 11;
			this->label6->Text = L"Imaginario";
			// 
			// txtimagsuma
			// 
			this->txtimagsuma->Location = System::Drawing::Point(159, 287);
			this->txtimagsuma->Name = L"txtimagsuma";
			this->txtimagsuma->Size = System::Drawing::Size(100, 20);
			this->txtimagsuma->TabIndex = 10;
			// 
			// btbsuma
			// 
			this->btbsuma->Location = System::Drawing::Point(110, 347);
			this->btbsuma->Name = L"btbsuma";
			this->btbsuma->Size = System::Drawing::Size(75, 23);
			this->btbsuma->TabIndex = 12;
			this->btbsuma->Text = L"Sumar";
			this->btbsuma->UseVisualStyleBackColor = true;
			this->btbsuma->Click += gcnew System::EventHandler(this, &Form1::btbsuma_Click);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(16, 9);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(59, 13);
			this->label7->TabIndex = 13;
			this->label7->Text = L"Complejo 1";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(11, 126);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(59, 13);
			this->label8->TabIndex = 14;
			this->label8->Text = L"Complejo 2";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(17, 232);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(34, 13);
			this->label9->TabIndex = 15;
			this->label9->Text = L"Suma";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(446, 488);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->btbsuma);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->txtimagsuma);
			this->Controls->Add(this->l�);
			this->Controls->Add(this->txtrealsuma);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtimag2);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtreal2);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txtimag1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtreal1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btbsuma_Click(System::Object^  sender, System::EventArgs^  e) {
				 CCOMPLEJO c1,c2;
				 c1.Set_real(System::Convert::ToDouble(txtreal1->Text));  //trayendo los textos que escribimos 
				 c2.Set_real(System::Convert::ToDouble(txtreal2->Text));
				 c1.Set_imag(System::Convert::ToDouble(txtimag1->Text));
				 c2.Set_imag(System::Convert::ToDouble(txtimag2->Text));
				 double sumareal,sumaimag;
				 sumareal=c1.Get_real()+c2.Get_real();
				 sumaimag=c1.Get_imag()+c2.Get_imag();
				 txtrealsuma->Text=System::Convert::ToString(sumareal);
				 txtimagsuma->Text=System::Convert::ToString(sumaimag);
			 }
};
}

