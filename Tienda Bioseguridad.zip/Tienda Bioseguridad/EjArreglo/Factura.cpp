#include "StdAfx.h"
#include "Factura.h"


Factura::Factura(string nombre,int celular,string direccion,int monto){
	this->nombre=nombre;
	this->celular=celular;
	this->direccion=direccion;
	this->monto=monto;
}

string Factura::getNombre(){return this->nombre;}
string Factura::getDireccion(){return this->direccion;}
int Factura::getCelular(){return this->celular; }
int Factura::getMonto(){return this->monto;}