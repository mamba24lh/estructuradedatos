#pragma once
#include <iostream>
using namespace std;
#include <string>


class Factura{
private:
	string nombre,direccion;
	int celular,monto;
public:
	Factura(string,int,string,int);
	string getNombre();
	string getDireccion();
	int getCelular();
	int getMonto();
};

