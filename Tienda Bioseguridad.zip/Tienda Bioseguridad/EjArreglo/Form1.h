#pragma once

#include <iostream>
#include <string>
#include "Vector.h"
#include <msclr\marshal_cppstd.h>
#include "Factura.h"
#include "stdafx.h"



namespace Tienda {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
    using namespace msclr::interop;
	// Variable Global
	Vector vectorDeLibros; 
	Vector colaDeLibros; 
	int pos=0; //variable auxiliar para la grilla
	//Factura factura; //factura a ingresar
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  grilla_libros;
	protected: 

	protected: 

	protected: 


	private: System::Windows::Forms::Button^  btnOrdenar;
	protected: 

	protected: 





	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  btnAnadir;
	private: System::Windows::Forms::TextBox^  textBoxLibro;




	private: System::Windows::Forms::Button^  btnEliminar;


	private: System::Windows::Forms::NotifyIcon^  notifyIcon1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::TextBox^  textBoxNombre;
	private: System::Windows::Forms::TextBox^  textBoxCelular;
	private: System::Windows::Forms::TextBox^  textBoxDireccion;
	private: System::Windows::Forms::TextBox^  textBoxMonto;
	private: System::Windows::Forms::TextBox^  textBoxTotal;








	private: System::ComponentModel::IContainer^  components;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->grilla_libros = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnOrdenar = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->btnAnadir = (gcnew System::Windows::Forms::Button());
			this->textBoxLibro = (gcnew System::Windows::Forms::TextBox());
			this->btnEliminar = (gcnew System::Windows::Forms::Button());
			this->notifyIcon1 = (gcnew System::Windows::Forms::NotifyIcon(this->components));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->textBoxNombre = (gcnew System::Windows::Forms::TextBox());
			this->textBoxCelular = (gcnew System::Windows::Forms::TextBox());
			this->textBoxDireccion = (gcnew System::Windows::Forms::TextBox());
			this->textBoxMonto = (gcnew System::Windows::Forms::TextBox());
			this->textBoxTotal = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_libros))->BeginInit();
			this->SuspendLayout();
			// 
			// grilla_libros
			// 
			this->grilla_libros->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_libros->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column1, 
				this->Column2});
			this->grilla_libros->Location = System::Drawing::Point(34, 168);
			this->grilla_libros->Margin = System::Windows::Forms::Padding(4);
			this->grilla_libros->Name = L"grilla_libros";
			this->grilla_libros->Size = System::Drawing::Size(380, 212);
			this->grilla_libros->TabIndex = 0;
			this->grilla_libros->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::dataGridView1_CellContentClick);
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Libro";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Precio";
			this->Column2->Name = L"Column2";
			// 
			// btnOrdenar
			// 
			this->btnOrdenar->Location = System::Drawing::Point(751, 347);
			this->btnOrdenar->Margin = System::Windows::Forms::Padding(4);
			this->btnOrdenar->Name = L"btnOrdenar";
			this->btnOrdenar->Size = System::Drawing::Size(105, 33);
			this->btnOrdenar->TabIndex = 2;
			this->btnOrdenar->Text = L"Ordenar";
			this->btnOrdenar->UseVisualStyleBackColor = true;
			this->btnOrdenar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(13, 34);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(141, 17);
			this->label2->TabIndex = 6;
			this->label2->Text = L"Nombre del producto";
			this->label2->Click += gcnew System::EventHandler(this, &Form1::label2_Click);
			// 
			// btnAnadir
			// 
			this->btnAnadir->Location = System::Drawing::Point(309, 72);
			this->btnAnadir->Margin = System::Windows::Forms::Padding(4);
			this->btnAnadir->Name = L"btnAnadir";
			this->btnAnadir->Size = System::Drawing::Size(105, 33);
			this->btnAnadir->TabIndex = 5;
			this->btnAnadir->Text = L"A�adir";
			this->btnAnadir->UseVisualStyleBackColor = true;
			this->btnAnadir->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// textBoxLibro
			// 
			this->textBoxLibro->Location = System::Drawing::Point(162, 29);
			this->textBoxLibro->Margin = System::Windows::Forms::Padding(4);
			this->textBoxLibro->Name = L"textBoxLibro";
			this->textBoxLibro->Size = System::Drawing::Size(252, 22);
			this->textBoxLibro->TabIndex = 4;
			this->textBoxLibro->TextChanged += gcnew System::EventHandler(this, &Form1::textBox1_TextChanged);
			// 
			// btnEliminar
			// 
			this->btnEliminar->Location = System::Drawing::Point(309, 113);
			this->btnEliminar->Margin = System::Windows::Forms::Padding(4);
			this->btnEliminar->Name = L"btnEliminar";
			this->btnEliminar->Size = System::Drawing::Size(105, 33);
			this->btnEliminar->TabIndex = 7;
			this->btnEliminar->Text = L"Eliminar";
			this->btnEliminar->UseVisualStyleBackColor = true;
			this->btnEliminar->Click += gcnew System::EventHandler(this, &Form1::btnEliminar_Click);
			// 
			// notifyIcon1
			// 
			this->notifyIcon1->Text = L"notifyIcon1";
			this->notifyIcon1->Visible = true;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(477, 173);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(58, 17);
			this->label1->TabIndex = 8;
			this->label1->Text = L"Nombre";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(477, 206);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(52, 17);
			this->label3->TabIndex = 9;
			this->label3->Text = L"Celular";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(477, 245);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(67, 17);
			this->label4->TabIndex = 10;
			this->label4->Text = L"Direccion";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(477, 289);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(170, 17);
			this->label5->TabIndex = 11;
			this->label5->Text = L"Monto con el que cancela";
			// 
			// textBoxNombre
			// 
			this->textBoxNombre->Location = System::Drawing::Point(674, 168);
			this->textBoxNombre->MaxLength = 120;
			this->textBoxNombre->Name = L"textBoxNombre";
			this->textBoxNombre->Size = System::Drawing::Size(182, 22);
			this->textBoxNombre->TabIndex = 12;
			// 
			// textBoxCelular
			// 
			this->textBoxCelular->Location = System::Drawing::Point(674, 206);
			this->textBoxCelular->MaxLength = 12;
			this->textBoxCelular->Name = L"textBoxCelular";
			this->textBoxCelular->Size = System::Drawing::Size(182, 22);
			this->textBoxCelular->TabIndex = 13;
			this->textBoxCelular->TextChanged += gcnew System::EventHandler(this, &Form1::textBoxCelular_TextChanged);
			// 
			// textBoxDireccion
			// 
			this->textBoxDireccion->Location = System::Drawing::Point(674, 245);
			this->textBoxDireccion->MaxLength = 500;
			this->textBoxDireccion->Name = L"textBoxDireccion";
			this->textBoxDireccion->Size = System::Drawing::Size(182, 22);
			this->textBoxDireccion->TabIndex = 14;
			// 
			// textBoxMonto
			// 
			this->textBoxMonto->Location = System::Drawing::Point(674, 289);
			this->textBoxMonto->MaxLength = 7;
			this->textBoxMonto->Name = L"textBoxMonto";
			this->textBoxMonto->Size = System::Drawing::Size(182, 22);
			this->textBoxMonto->TabIndex = 15;
			// 
			// textBoxTotal
			// 
			this->textBoxTotal->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBoxTotal->Location = System::Drawing::Point(34, 387);
			this->textBoxTotal->Name = L"textBoxTotal";
			this->textBoxTotal->ReadOnly = true;
			this->textBoxTotal->Size = System::Drawing::Size(380, 26);
			this->textBoxTotal->TabIndex = 16;
			this->textBoxTotal->Text = L"Total: 0 Bs.";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(942, 427);uri
			this->Controls->Add(this->textBoxTotal);
			this->Controls->Add(this->textBoxMonto);
			this->Controls->Add(this->textBoxDireccion);
			this->Controls->Add(this->textBoxCelular);
			this->Controls->Add(this->textBoxNombre);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnEliminar);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btnAnadir);
			this->Controls->Add(this->textBoxLibro);
			this->Controls->Add(this->btnOrdenar);
			this->Controls->Add(this->grilla_libros);
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"Form1";
			this->Text = L"Tienda";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_libros))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 }//
	private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {	 
				
				 if (textBoxNombre->Text!="" && textBoxCelular->Text!="" && textBoxDireccion->Text!="" && textBoxMonto->Text!=""){
				 string nombre=marshal_as<std::string>(textBoxNombre->Text);
				 int celular=System::Convert::ToInt32(textBoxCelular->Text);
				 string direccion=marshal_as<std::string>(textBoxDireccion->Text);
				 int monto=System::Convert::ToInt32(textBoxMonto->Text);

				 int vuelto=0;
				 int precioTotal=0;
				 for (int i=0; i<colaDeLibros.Get_tamano(); i++){
					precioTotal+=colaDeLibros.Get_vector(i).getPrecio();
				 }
				 
				 if (precioTotal>monto){
					 MessageBox::Show("El monto con el que paga no es suficiente para el precio total de los productos","Error");
				 }else{
					 if (colaDeLibros.Get_tamano()==0){
					 MessageBox::Show("No ha seleccionado ningun producto","Error");
					 }else{
						  
					 Factura factura(nombre,celular,direccion,precioTotal);
					 vuelto=monto-precioTotal;
					 MessageBox::Show("Compra exitosa: \nNombre: "+gcnew String(factura.getNombre().c_str())
						 +"\nCelular: "+System::Convert::ToString(factura.getCelular())
						 +"\nDireccion: "+gcnew String(factura.getDireccion().c_str())
						 +"\nTotal: "+ System::Convert::ToString(factura.getMonto())
						 +"\n"
						 +" \nCambio: "+System::Convert::ToString(vuelto)+" Bs.");
				      }
				 }
		}else{
		MessageBox::Show("Revisar los datos introducidos del cliente","Error");
		}
			 
			 }//
	private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
			 }//
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
   
	
	int posicionLibro=0;
	if (vectorDeLibros.Buscar(marshal_as<std::string>(textBoxLibro->Text),posicionLibro) ){
				Libro libro=vectorDeLibros.Get_vector(posicionLibro);		
				colaDeLibros.Insertar(libro,pos);
				grilla_libros->RowCount=colaDeLibros.Get_tamano()+1;
				grilla_libros->Rows[pos]->Cells[0]->Value=gcnew String(libro.getNombre().c_str());
				grilla_libros->Rows[pos]->Cells[1]->Value=System::Convert::ToString(libro.getPrecio());
				pos++;
	}


	
				int precioTotal=0;
				 for (int i=0; i<colaDeLibros.Get_tamano(); i++){
					precioTotal+=colaDeLibros.Get_vector(i).getPrecio();
				 }
		textBoxTotal->Text="Total: "+precioTotal+" Bs."; 

}//
private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}//

private: System::Void btnEliminar_Click(System::Object^  sender, System::EventArgs^  e) {
			
		if (colaDeLibros.Eliminar(marshal_as<std::string>(textBoxLibro->Text))){
		  grilla_libros->RowCount=colaDeLibros.Get_tamano()+1;
		  	
			for (int i=0; i<colaDeLibros.Get_tamano(); i++){
				Libro libro=colaDeLibros.Get_vector(i);
				grilla_libros->Rows[i]->Cells[0]->Value=gcnew String(libro.getNombre().c_str());
				grilla_libros->Rows[i]->Cells[1]->Value=System::Convert::ToString(libro.getPrecio());
			}
			pos--;
		}

		
				int precioTotal=0;
				 for (int i=0; i<colaDeLibros.Get_tamano(); i++){
					precioTotal+=colaDeLibros.Get_vector(i).getPrecio();
				 }
		textBoxTotal->Text="Total: "+precioTotal+" Bs."; //muestra el precio en el labelTotal

}//
//
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 


			Libro libro1("Traje de bioseguridad",120),libro2("Mascarillas N95",95)
			,libro3("Pruebas rapidas covid-19",850),libro4("Termometros digitales",250),libro5("Caja guantes de latex",80);
			vectorDeLibros.Insertar(libro1,0);
			vectorDeLibros.Insertar(libro2,1);
			vectorDeLibros.Insertar(libro3,2);
			vectorDeLibros.Insertar(libro4,3);
			vectorDeLibros.Insertar(libro5,4);

		 }//



private: System::Void textBoxCelular_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}


