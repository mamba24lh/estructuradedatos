
#include "StdAfx.h"
#include "Libro.h"

Libro::Libro(void){
this->nombre="";
this->precio=0;
}

Libro::Libro(string nombre,int precio){
this->nombre=nombre;
this->precio=precio;
}

string Libro::getNombre(){
return this->nombre;
}

void Libro::setNombre(string nombre){
this->nombre=nombre;
}
int Libro::getPrecio(){
return this->precio;
}

void Libro::setPrecio(int precio){
this->precio=precio;
}