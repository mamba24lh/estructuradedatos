#pragma once
#include <iostream>
using namespace std;
#include <string>


class Libro{
private:
string nombre;
int precio;
public:
	Libro(void);
	Libro(string nombre,int precio);
	string getNombre();
	void setNombre(string nombre);
	int getPrecio();
	void setPrecio(int precio);
};

