#pragma once
#define MAX 10
#include <iostream>
using namespace std;
#include <string>
#include "Libro.h"


class Vector{
private:
	Libro vec[MAX];
	int tamano;
public:
	Vector(void); // constructor
	~Vector(void); //destructor
	int Get_tamano();
	void Set_tamano(int tam);

	Libro Get_vector(int posicion);
	void Set_vector(int posicion, Libro _elemento); 
	void Incrementar();
	void Decrementar();
	bool Vacio_vector();
	bool Lleno_vector();
	bool Insertar(Libro _elemento, int posicion);
	bool Eliminar(string _elemento);
	bool Buscar(string elem, int &posicion);
	// Tradicional
	void ordenarVector(Libro vec[], int tam);
};
1
